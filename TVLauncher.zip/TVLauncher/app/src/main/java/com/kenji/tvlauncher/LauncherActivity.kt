package com.kenji.tvlauncher

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Calendar
import java.util.concurrent.Executors

class VH(v: View) : RecyclerView.ViewHolder(v) {
    val icon: ImageView = v.findViewById(R.id.icon)
    val label: TextView = v.findViewById(R.id.label)
}

private class Slot(val view: FrameLayout, val icon: ImageView, val plus: TextView)

class LauncherActivity : Activity() {

    companion object {
        private val BG = Color.parseColor("#050505")
        private const val ANIM_MS = 150L
        private const val COLUMNS = 8
        private var cache: List<AppEntry>? = null // survives activity recreation, instant 2nd start
    }

    private lateinit var prefs: Prefs
    private lateinit var glow: GradientDrawable
    private lateinit var heroTitle: TextView
    private lateinit var heroSub: TextView
    private lateinit var greeting: TextView
    private lateinit var grid: RecyclerView
    private lateinit var adapter: AppAdapter

    private val slots = ArrayList<Slot>()
    private val io = Executors.newSingleThreadExecutor()
    private var apps: List<AppEntry> = emptyList()
    private var dockApps: List<AppEntry?> = List(5) { null }
    private var favSet: Set<String> = emptySet()
    private var shownTint = BG
    private var targetTint = BG
    private var glowAnim: ValueAnimator? = null
    private var restored = false
    private var lastDock = 0

    private val tick = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) = updateGreeting()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)
        favSet = prefs.favorites()

        heroTitle = findViewById(R.id.heroTitle)
        heroSub = findViewById(R.id.heroSub)
        greeting = findViewById(R.id.greeting)
        grid = findViewById(R.id.grid)

        glow = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(BG, BG)).apply {
            gradientType = GradientDrawable.RADIAL_GRADIENT
            gradientRadius = resources.displayMetrics.widthPixels * 0.6f
            setGradientCenter(0.5f, 0.3f)
        }
        findViewById<View>(R.id.glow).background = glow

        buildDock()
        bindButton(R.id.btnNetwork, "Network", Settings.ACTION_WIFI_SETTINGS)
        bindButton(R.id.btnApps, "Apps", Settings.ACTION_APPLICATION_SETTINGS)
        bindButton(R.id.btnSettings, "Settings", Settings.ACTION_SETTINGS)

        adapter = AppAdapter()
        grid.layoutManager = GridLayoutManager(this, COLUMNS)
        grid.adapter = adapter
        grid.setHasFixedSize(true)
        grid.itemAnimator = null

        val l = prefs.last
        if (l.startsWith("dock:")) lastDock = l.removePrefix("dock:").toIntOrNull()?.coerceIn(0, 4) ?: 0

        cache?.let { applyApps(it) }
    }

    override fun onStart() {
        super.onStart()
        updateGreeting()
        registerReceiver(tick, IntentFilter(Intent.ACTION_TIME_TICK))
        io.execute {
            val fresh = AppRepo.load(this)
            runOnUiThread {
                if (!isDestroyed && fresh.map { it.key } != apps.map { it.key }) {
                    cache = fresh
                    applyApps(fresh)
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        try { unregisterReceiver(tick) } catch (e: Exception) { }
    }

    override fun onDestroy() {
        super.onDestroy()
        glowAnim?.cancel()
        io.shutdown()
    }

    /** HOME pressed while we're already running: go back to the dock. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) {
            grid.scrollToPosition(0)
            focusDock(lastDock)
        }
    }

    /** A launcher must never close itself: BACK from the grid returns to the dock, otherwise no-op. */
    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (grid.hasFocus()) focusDock(lastDock)
    }

    // ---------------------------------------------------------------- UI building

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun buildDock() {
        val dock = findViewById<LinearLayout>(R.id.dock)
        val size = dp(84); val iconSize = dp(60); val gap = dp(6)
        for (i in 0 until 5) {
            val fl = FrameLayout(this).apply {
                id = View.generateViewId()
                isFocusable = true
                isClickable = true
                isLongClickable = true
                defaultFocusHighlightEnabled = false
                background = getDrawable(R.drawable.focus_glass)
                layoutParams = LinearLayout.LayoutParams(size, size).apply { setMargins(gap, gap, gap, gap) }
            }
            val icon = ImageView(this).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = FrameLayout.LayoutParams(iconSize, iconSize, Gravity.CENTER)
            }
            val plus = TextView(this).apply {
                text = "+"
                textSize = 30f
                setTextColor(0x66FFFFFF)
                gravity = Gravity.CENTER
                layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            }
            fl.addView(icon); fl.addView(plus)
            fl.nextFocusUpId = R.id.btnSettings
            fl.setOnFocusChangeListener { v, has ->
                animateFocus(v, has, 1.15f)
                if (has) {
                    lastDock = i
                    prefs.last = "dock:$i"
                    showDockHero(i)
                }
            }
            fl.setOnClickListener { dockApps[i]?.let { launch(it) } ?: pickForSlot(i) }
            fl.setOnLongClickListener { pickForSlot(i); true }
            dock.addView(fl)
            slots.add(Slot(fl, icon, plus))
        }
    }

    private fun bindButton(id: Int, label: String, action: String) {
        val v = findViewById<TextView>(id)
        v.nextFocusDownId = slots[2].view.id
        v.setOnClickListener {
            try {
                startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                Toast.makeText(this, "Not available on this device", Toast.LENGTH_SHORT).show()
            }
        }
        v.setOnFocusChangeListener { x, has ->
            animateFocus(x, has, 1.08f)
            if (has) showHero(label, "", null)
        }
    }

    // ---------------------------------------------------------------- data -> UI

    private fun applyApps(list: List<AppEntry>) {
        apps = list
        refreshDock()
        adapter.submit(list)
        if (!restored) {
            restored = true
            val l = prefs.last
            if (l.startsWith("grid:")) focusGridPkg(l.removePrefix("grid:")) else focusDock(lastDock)
        }
    }

    private fun refreshDock() {
        dockApps = AppRepo.resolveDock(apps, prefs)
        for (i in 0 until 5) {
            val a = dockApps[i]
            slots[i].icon.setImageDrawable(a?.icon)
            slots[i].plus.visibility = if (a == null) View.VISIBLE else View.GONE
        }
        val f = slots.indexOfFirst { it.view.isFocused }
        if (f >= 0) showDockHero(f)
    }

    private fun showDockHero(i: Int) {
        val a = dockApps[i]
        if (a == null) showHero("Add an app", "Press OK to choose", null)
        else showHero(a.label, "Hold OK to change this slot", a.tint)
    }

    private fun showHero(t: String, sub: String, tint: Int?) {
        if (heroTitle.text.toString() != t) {
            heroTitle.alpha = 0f
            heroTitle.text = t
            heroTitle.animate().alpha(1f).setDuration(ANIM_MS).start()
        }
        heroSub.text = sub
        if (tint != null) tintGlow(tint)
    }

    private fun mix(c: Int, a: Float): Int {
        val r = (Color.red(BG) * (1 - a) + Color.red(c) * a).toInt()
        val g = (Color.green(BG) * (1 - a) + Color.green(c) * a).toInt()
        val b = (Color.blue(BG) * (1 - a) + Color.blue(c) * a).toInt()
        return Color.rgb(r, g, b)
    }

    private fun tintGlow(c: Int) {
        if (c == targetTint) return
        targetTint = c
        glowAnim?.cancel()
        glowAnim = ValueAnimator.ofObject(ArgbEvaluator(), shownTint, c).apply {
            duration = 180
            addUpdateListener {
                shownTint = it.animatedValue as Int
                glow.colors = intArrayOf(mix(shownTint, 0.30f), BG)
            }
            start()
        }
    }

    private fun animateFocus(v: View, has: Boolean, scale: Float) {
        val s = if (has) scale else 1f
        v.animate().scaleX(s).scaleY(s).setDuration(ANIM_MS)
            .setInterpolator(DecelerateInterpolator()).start()
    }

    private fun updateGreeting() {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        greeting.text = when {
            h < 12 -> "Good morning"
            h < 18 -> "Good afternoon"
            else -> "Good evening"
        }
    }

    // ---------------------------------------------------------------- focus helpers

    private fun focusDock(i: Int) {
        slots[i.coerceIn(0, 4)].view.requestFocus()
    }

    private fun focusGridPkg(pkg: String) {
        val idx = adapter.items.indexOfFirst { it.pkg == pkg }
        if (idx < 0) { focusDock(lastDock); return }
        grid.scrollToPosition(idx)
        grid.postDelayed({
            val v = grid.findViewHolderForAdapterPosition(idx)?.itemView
            if (v != null) v.requestFocus() else focusDock(lastDock)
        }, 60)
    }

    // ---------------------------------------------------------------- actions

    private fun launch(e: AppEntry) {
        try {
            val cat = if (e.leanback) Intent.CATEGORY_LEANBACK_LAUNCHER else Intent.CATEGORY_LAUNCHER
            startActivity(
                Intent(Intent.ACTION_MAIN).addCategory(cat)
                    .setComponent(ComponentName(e.pkg, e.cls))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            )
        } catch (ex: Exception) {
            Toast.makeText(this, "Cannot open ${e.label}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun dialog() = AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)

    private fun pickForSlot(slot: Int) {
        val names = arrayOf("Reset to default") + apps.map { it.label }.toTypedArray()
        dialog().setTitle("Dock slot ${slot + 1}").setItems(names) { _, which ->
            prefs.setDock(slot, if (which == 0) null else apps[which - 1].key)
            refreshDock()
        }.show()
    }

    private fun appOptions(e: AppEntry) {
        val items = ArrayList<String>()
        items.add(if (e.pkg in favSet) "Remove from Favorites" else "Add to Favorites")
        for (i in 1..5) items.add("Put in dock slot $i")
        items.add("App info")
        dialog().setTitle(e.label).setItems(items.toTypedArray()) { _, which ->
            when (which) {
                0 -> {
                    prefs.toggleFavorite(e.pkg)
                    favSet = prefs.favorites()
                    adapter.submit(apps)
                    focusGridPkg(e.pkg)
                }
                in 1..5 -> { prefs.setDock(which - 1, e.key); refreshDock() }
                else -> try {
                    startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", e.pkg, null))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (ex: Exception) {
                    Toast.makeText(this, "Not available", Toast.LENGTH_SHORT).show()
                }
            }
        }.show()
    }

    // ---------------------------------------------------------------- grid adapter

    private inner class AppAdapter : RecyclerView.Adapter<VH>() {
        var items: List<AppEntry> = emptyList()

        fun submit(list: List<AppEntry>) {
            items = list.sortedWith(
                compareByDescending<AppEntry> { it.pkg in favSet }.thenBy { it.label.lowercase() }
            )
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(layoutInflater.inflate(R.layout.item_app, parent, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val e = items[position]
            val fav = e.pkg in favSet
            h.icon.setImageDrawable(e.icon)
            h.label.text = if (fav) "★ ${e.label}" else e.label
            h.itemView.scaleX = if (h.itemView.isFocused) 1.12f else 1f
            h.itemView.scaleY = h.itemView.scaleX
            h.itemView.setOnClickListener { launch(e) }
            h.itemView.setOnLongClickListener { appOptions(e); true }
            h.itemView.setOnFocusChangeListener { v, has ->
                animateFocus(v, has, 1.12f)
                if (has) {
                    prefs.last = "grid:${e.pkg}"
                    showHero(e.label, if (fav) "Favorite · hold OK for options" else "Hold OK for options", e.tint)
                }
            }
        }
    }
}
