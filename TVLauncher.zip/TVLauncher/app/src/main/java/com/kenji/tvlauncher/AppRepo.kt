package com.kenji.tvlauncher

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable

data class AppEntry(
    val pkg: String,
    val cls: String,
    val label: String,
    val icon: Drawable,
    val leanback: Boolean,
    val tint: Int
) {
    val key: String get() = "$pkg/$cls"
}

object AppRepo {

    /**
     * Default dock matching. Apps are discovered by their installed LABEL, never by
     * hard-coded package IDs. Keys are tried in order: exact label match first,
     * then "label contains". EDIT THIS LIST to change the automatic defaults.
     */
    val DOCK_DEFAULTS: List<List<String>> = listOf(
        listOf("LOKTV", "LOK TV", "LOK-TV"),
        listOf("Netflix"),
        listOf("YouTube"),
        listOf("Google Play Store", "Play Store"),
        listOf("Converge Xperience", "Xperience", "Converge")
    )

    /** Blocking; call from a background thread. */
    fun load(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        val map = LinkedHashMap<String, AppEntry>() // keyed by package => no duplicates
        for ((category, lean) in listOf(
            Intent.CATEGORY_LEANBACK_LAUNCHER to true,
            Intent.CATEGORY_LAUNCHER to false
        )) {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (ri in pm.queryIntentActivities(intent, 0)) {
                val ai = ri.activityInfo ?: continue
                if (ai.packageName == ctx.packageName) continue
                if (map.containsKey(ai.packageName)) continue
                val icon = try { ri.loadIcon(pm) } catch (e: Exception) { continue }
                val label = ri.loadLabel(pm)?.toString() ?: ai.packageName
                map[ai.packageName] = AppEntry(ai.packageName, ai.name, label, icon, lean, tintOf(icon))
            }
        }
        return map.values.sortedBy { it.label.lowercase() }
    }

    /** Cheap average colour of the icon, used for the ambient glow. */
    private fun tintOf(d: Drawable): Int {
        return try {
            val s = 8
            val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
            d.setBounds(0, 0, s, s)
            d.draw(Canvas(b))
            var r = 0L; var g = 0L; var bl = 0L; var n = 0
            for (x in 0 until s) for (y in 0 until s) {
                val p = b.getPixel(x, y)
                if ((p ushr 24) > 128) {
                    r += (p shr 16) and 0xFF; g += (p shr 8) and 0xFF; bl += p and 0xFF; n++
                }
            }
            b.recycle()
            if (n == 0) 0xFF666666.toInt()
            else (0xFF shl 24) or ((r / n).toInt() shl 16) or ((g / n).toInt() shl 8) or (bl / n).toInt()
        } catch (e: Exception) {
            0xFF666666.toInt()
        }
    }

    private fun matchDefault(apps: List<AppEntry>, keys: List<String>, taken: Set<String>): AppEntry? {
        val pool = apps.filter { it.pkg !in taken }
        for (k in keys) pool.firstOrNull { it.label.equals(k, true) }?.let { return it }
        for (k in keys) pool.firstOrNull { it.label.contains(k, true) }?.let { return it }
        return null
    }

    /** Five dock entries; null = placeholder ("+"). */
    fun resolveDock(apps: List<AppEntry>, prefs: Prefs): List<AppEntry?> {
        val out = MutableList<AppEntry?>(5) { null }
        val taken = HashSet<String>()
        for (i in 0 until 5) {
            val k = prefs.dock(i) ?: continue
            apps.firstOrNull { it.key == k }?.let { out[i] = it; taken.add(it.pkg) }
        }
        for (i in 0 until 5) {
            if (out[i] == null && prefs.dock(i) == null) {
                matchDefault(apps, DOCK_DEFAULTS[i], taken)?.let { out[i] = it; taken.add(it.pkg) }
            }
        }
        return out
    }
}
