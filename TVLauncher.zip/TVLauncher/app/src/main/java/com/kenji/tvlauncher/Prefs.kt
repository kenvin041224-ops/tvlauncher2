package com.kenji.tvlauncher

import android.content.Context

/** Tiny SharedPreferences wrapper: dock choices, favorites, last focused item. */
class Prefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    /** Stored "package/class" for a dock slot, or null = use automatic default. */
    fun dock(i: Int): String? = p.getString("dock$i", null)

    fun setDock(i: Int, key: String?) {
        val e = p.edit()
        if (key == null) e.remove("dock$i") else e.putString("dock$i", key)
        e.apply()
    }

    fun favorites(): Set<String> = HashSet(p.getStringSet("fav", emptySet()) ?: emptySet())

    fun toggleFavorite(pkg: String) {
        val s = favorites().toMutableSet()
        if (!s.add(pkg)) s.remove(pkg)
        p.edit().putStringSet("fav", s).apply()
    }

    var last: String
        get() = p.getString("last", "dock:0") ?: "dock:0"
        set(v) { p.edit().putString("last", v).apply() }
}
