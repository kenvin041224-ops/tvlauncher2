# TV Launcher (Apple TV-inspired) – Android TV 14

Native Kotlin launcher for the Converge ZTE ZXV10 B866V2F (Amlogic S905Y4, 2 GB RAM, 1080p).
No root, no special permissions, no background services, no network access, no blur/video.

## STATUS – read this first
- Source code is complete, but **it has NOT been compiled or tested.** The environment it was written in had no
  Android SDK/Gradle access, so no APK exists yet and nothing has been tested on a ZTE box.
- Build it once (below) and report any compile error; they should be small.

## Build (Android Studio – easiest)
1. Install Android Studio (Koala or newer; it bundles JDK 17).
2. File > Open > select the `TVLauncher` folder. Let Gradle sync (it downloads Gradle 8.7, AGP 8.5.2, SDK 34 –
   accept the SDK licence prompt).
3. Build > Build APK(s). Debug APK: `app/build/outputs/apk/debug/app-debug.apk`.
4. Release APK: Build > Generate Signed App Bundle / APK, or `./gradlew assembleRelease`
   (release is signed with the debug key so it installs for personal use).

Command line (JDK 17 + Android SDK installed, `ANDROID_HOME` set; run `gradle wrapper` once if `gradlew` is missing):
`./gradlew assembleDebug`

## Install on the box (no ADB required)
1. On the TV: Settings > Device Preferences > Security & restrictions > Unknown sources: allow for your file manager.
2. Copy the APK to a USB stick, open it with a TV file manager (e.g. "File Commander" / "X-plore") and install.
   Alternative: "Send Files to TV" app, or `adb install app-debug.apk` if you do enable ADB.
3. Press HOME. If Android asks which home app to use, choose "TV Launcher" > "Just once" first to test.
   Pick "Always" only after everything works.

**If the box won't offer a home-app choice:** some operator firmware locks the default launcher. Then this app can
only be opened from the app list (it also has a LEANBACK_LAUNCHER entry) and cannot replace Converge's home.
Don't try workarounds – just use it as a normal app.

## Remote controls
D-pad moves focus, OK launches, **hold OK** on an app = options (Favorite / put in dock slot / App info),
**hold OK** on a dock slot = choose its app. BACK in the grid returns to the dock; BACK on the dock does nothing
(the launcher never closes). HOME returns to the dock. Last focused item is remembered.

## Customising the dock
- On screen: hold OK on a dock slot (or on any app > "Put in dock slot N"). "Reset to default" restores auto-match.
- Defaults: edit `DOCK_DEFAULTS` in `AppRepo.kt`. Apps are matched by installed *label*
  (LOKTV, Netflix, YouTube, Google Play Store, Converge Xperience) – no package IDs are hard-coded.
  A slot with no match shows "+" so you can assign it later.
- Prime Video is not in the dock by default.

## Recovery (return to the stock Converge launcher)
This app never disables or modifies the Converge launcher, so recovery is just removing ours as the default:
1. Easiest: Settings button (top right of this launcher) > Apps > TV Launcher > **Clear defaults** (or Uninstall).
   Wording varies; "Open by default"/"Clear defaults" may be under Apps > See all apps > TV Launcher.
2. Or: Settings > Apps > See all apps > TV Launcher > **Uninstall**. HOME then goes back to Converge.
3. If you can't reach Settings (remote/launcher problem): power-cycle the box, then when the home chooser or
   Converge screen appears pick Converge; or, if ADB is enabled:
   `adb uninstall com.kenji.tvlauncher`
4. Last resort: Converge support / factory reset (erases your data; not needed in normal use).
Do not disable the stock launcher until this one has been confirmed working.

## Project layout
`app/src/main/java/com/kenji/tvlauncher/` – `LauncherActivity.kt` (UI, focus, animations), `AppRepo.kt`
(app discovery, dock defaults), `Prefs.kt` (favorites, dock, last focus).
`AndroidManifest.xml` – HOME + DEFAULT + LEANBACK_LAUNCHER, `<queries>` for Android 11+ visibility, landscape,
opaque theme, no permissions. Animations are 150 ms (scale 1.12–1.15 + fading glass highlight);
ambient glow is a single radial gradient tinted from the focused icon.

## Verification checklist (do on the device)
- [ ] Builds without errors  - [ ] 5 dock slots visible  - [ ] LOKTV/Netflix/YouTube/Play Store/Converge found
- [ ] OK launches each  - [ ] BACK/HOME behave  - [ ] Grid scrolls smoothly  - [ ] Favorites + dock edit work
